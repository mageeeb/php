<?php

// paramètres de connexions
const DB_HOST = "localhost";
const DB_LOGIN = "root";
const DB_PWD = "";
const DB_NAME = "exe29";
const DB_PORT = 3307;
const DB_CHARSET = "utf8mb4";